// AttendEase Attendance Management System JavaScript

// Global variables
let currentUser = null;
let attendanceData = [];
let sidebarOpen = false;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    updateDateTime();
    setInterval(updateDateTime, 60000); // Update every minute
});

// Initialize application
function initializeApp() {
    // Check if user is logged in
    const userData = localStorage.getItem('currentUser');
    if (userData) {
        currentUser = JSON.parse(userData);
        updateUserInterface();
    }
    
    // Load attendance data
    loadAttendanceData();
    
    // Initialize charts
    initializeCharts();
    
    // Setup mobile menu
    setupMobileMenu();
}

// Setup event listeners
function setupEventListeners() {
    // Navigation links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', handleNavigation);
    });
    
    // Authentication forms
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    // Attendance actions
    const checkInBtn = document.querySelector('.action-card.check-in');
    const checkOutBtn = document.querySelector('.action-card.check-out');
    const markAttendanceBtn = document.getElementById('markAttendanceBtn');
    
    if (checkInBtn) {
        checkInBtn.addEventListener('click', handleCheckIn);
    }
    
    if (checkOutBtn) {
        checkOutBtn.addEventListener('click', handleCheckOut);
    }
    
    if (markAttendanceBtn) {
        markAttendanceBtn.addEventListener('click', openMarkAttendanceModal);
    }
    
    // Modal controls
    setupModalControls();
    
    // Form validations
    setupFormValidations();
    
    // Filter controls
    setupFilterControls();
    
    // Export functions
    setupExportFunctions();
}

// Handle navigation
function handleNavigation(e) {
    e.preventDefault();
    
    const target = e.target.getAttribute('href');
    if (target && target !== '#') {
        // Update active nav link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        e.target.classList.add('active');
        
        // Navigate to page (in a real app, this would use a router)
        if (target.includes('.html')) {
            window.location.href = target;
        }
    }
}

// Handle login
function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Simple validation (in a real app, this would be server-side)
    if (email && password) {
        // Simulate login success
        currentUser = {
            id: 1,
            name: 'John Doe',
            email: email,
            role: 'admin',
            avatar: 'fas fa-user'
        };
        
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Show success message
        showNotification('Login successful! Redirecting...', 'success');
        
        // Redirect to dashboard
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
    } else {
        showNotification('Please fill in all fields', 'error');
    }
}

// Handle registration
function handleRegister(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const firstName = formData.get('firstName');
    const lastName = formData.get('lastName');
    const email = formData.get('email');
    const password = formData.get('password');
    const confirmPassword = formData.get('confirmPassword');
    
    // Validation
    if (password !== confirmPassword) {
        showNotification('Passwords do not match', 'error');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Password must be at least 6 characters', 'error');
        return;
    }
    
    // Simulate registration success
    showNotification('Registration successful! Please login.', 'success');
    
    // Redirect to login
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 1500);
}

// Handle check in
function handleCheckIn() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    // Check if already checked in today
    const today = now.toDateString();
    const existingCheckIn = attendanceData.find(record => 
        record.date === today && record.checkIn && !record.checkOut
    );
    
    if (existingCheckIn) {
        showNotification('You have already checked in today', 'warning');
        return;
    }
    
    // Add attendance record
    const attendanceRecord = {
        id: Date.now(),
        date: today,
        checkIn: timeString,
        checkOut: null,
        status: now.getHours() >= 9 ? 'late' : 'present',
        userId: currentUser.id
    };
    
    attendanceData.push(attendanceRecord);
    saveAttendanceData();
    
    showNotification(`Checked in at ${timeString}`, 'success');
    updateDashboard();
}

// Handle check out
function handleCheckOut() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    // Find today's check-in record
    const today = now.toDateString();
    const todayRecord = attendanceData.find(record => 
        record.date === today && record.checkIn && !record.checkOut
    );
    
    if (!todayRecord) {
        showNotification('You need to check in first', 'warning');
        return;
    }
    
    // Update check-out time
    todayRecord.checkOut = timeString;
    saveAttendanceData();
    
    showNotification(`Checked out at ${timeString}`, 'success');
    updateDashboard();
}

// Open mark attendance modal
function openMarkAttendanceModal() {
    const modal = document.getElementById('markAttendanceModal');
    if (modal) {
        modal.classList.add('active');
        
        // Set today's date as default
        const today = new Date().toISOString().split('T')[0];
        const dateInput = document.getElementById('attendanceDate');
        if (dateInput) {
            dateInput.value = today;
        }
    }
}

// Setup modal controls
function setupModalControls() {
    // Close modal buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', closeModal);
    });
    
    // Cancel buttons
    document.querySelectorAll('[id$="Cancel"]').forEach(btn => {
        btn.addEventListener('click', closeModal);
    });
    
    // Save buttons
    document.querySelectorAll('[id$="Attendance"]').forEach(btn => {
        btn.addEventListener('click', saveAttendance);
    });
    
    // Generate report modal
    const generateReportBtn = document.getElementById('generateReportBtn');
    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', openGenerateReportModal);
    }
    
    // Report period change
    const reportPeriod = document.getElementById('reportPeriod');
    if (reportPeriod) {
        reportPeriod.addEventListener('change', function() {
            const customDateRange = document.getElementById('customDateRange');
            if (customDateRange) {
                customDateRange.style.display = this.value === 'custom' ? 'block' : 'none';
            }
        });
    }
}

// Close modal
function closeModal() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('active');
    });
}

// Save attendance
function saveAttendance() {
    const form = document.getElementById('markAttendanceForm');
    if (!form) return;
    
    const formData = new FormData(form);
    const attendanceRecord = {
        id: Date.now(),
        employeeId: formData.get('employee'),
        date: formData.get('date'),
        checkIn: formData.get('checkInTime'),
        checkOut: formData.get('checkOutTime') || null,
        status: formData.get('status'),
        notes: formData.get('notes') || ''
    };
    
    attendanceData.push(attendanceRecord);
    saveAttendanceData();
    
    showNotification('Attendance saved successfully', 'success');
    closeModal();
    
    // Refresh attendance table if on attendance page
    if (window.location.href.includes('attendance.html')) {
        updateAttendanceTable();
    }
}

// Open generate report modal
function openGenerateReportModal() {
    const modal = document.getElementById('generateReportModal');
    if (modal) {
        modal.classList.add('active');
    }
}

// Setup form validations
function setupFormValidations() {
    // Password strength indicator
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
        passwordInput.addEventListener('input', updatePasswordStrength);
    }
    
    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(btn => {
        btn.addEventListener('click', togglePasswordVisibility);
    });
}

// Update password strength
function updatePasswordStrength(e) {
    const password = e.target.value;
    const strengthBar = document.querySelector('.strength-bar');
    const strengthText = document.querySelector('.strength-text');
    
    if (!strengthBar || !strengthText) return;
    
    let strength = 0;
    let strengthLabel = 'Weak';
    
    if (password.length >= 8) strength++;
    if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
    if (password.match(/[0-9]/)) strength++;
    if (password.match(/[^a-zA-Z0-9]/)) strength++;
    
    if (strength === 0) {
        strengthLabel = 'Very Weak';
        strengthBar.style.background = '#dc2626';
    } else if (strength === 1) {
        strengthLabel = 'Weak';
        strengthBar.style.background = '#f59e0b';
    } else if (strength === 2) {
        strengthLabel = 'Fair';
        strengthBar.style.background = '#eab308';
    } else if (strength === 3) {
        strengthLabel = 'Good';
        strengthBar.style.background = '#84cc16';
    } else {
        strengthLabel = 'Strong';
        strengthBar.style.background = '#16a34a';
    }
    
    strengthBar.style.width = `${(strength / 4) * 100}%`;
    strengthText.textContent = strengthLabel;
}

// Toggle password visibility
function togglePasswordVisibility(e) {
    const button = e.target.closest('.toggle-password');
    const input = button.previousElementSibling;
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Setup filter controls
function setupFilterControls() {
    // Filter selects
    document.querySelectorAll('.filter-select').forEach(select => {
        select.addEventListener('change', applyFilters);
    });
    
    // Filter dates
    document.querySelectorAll('.filter-date').forEach(input => {
        input.addEventListener('change', applyFilters);
    });
    
    // Search input
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(applyFilters, 300));
    }
}

// Apply filters
function applyFilters() {
    // This would filter the displayed data based on selected filters
    console.log('Applying filters...');
    
    // Update tables and charts
    if (window.location.href.includes('attendance.html')) {
        updateAttendanceTable();
    } else if (window.location.href.includes('reports.html')) {
        updateReports();
    }
}

// Setup export functions
function setupExportFunctions() {
    // Export buttons
    document.getElementById('exportBtn')?.addEventListener('click', exportToExcel);
    document.getElementById('printBtn')?.addEventListener('click', printReport);
    document.getElementById('exportExcel')?.addEventListener('click', exportToExcel);
    document.getElementById('exportPDF')?.addEventListener('click', exportToPDF);
    document.getElementById('printReport')?.addEventListener('click', printReport);
}

// Export to Excel
function exportToExcel() {
    showNotification('Exporting to Excel...', 'info');
    
    // Simulate export
    setTimeout(() => {
        showNotification('Excel file downloaded successfully', 'success');
    }, 1500);
}

// Export to PDF
function exportToPDF() {
    showNotification('Exporting to PDF...', 'info');
    
    // Simulate export
    setTimeout(() => {
        showNotification('PDF file downloaded successfully', 'success');
    }, 1500);
}

// Print report
function printReport() {
    window.print();
}

// Setup mobile menu
function setupMobileMenu() {
    const menuToggle = document.querySelector('.menu-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (menuToggle && sidebar) {
        menuToggle.addEventListener('click', () => {
            sidebarOpen = !sidebarOpen;
            sidebar.classList.toggle('active');
        });
    }
}

// Update date and time
function updateDateTime() {
    const now = new Date();
    const dateString = now.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    
    const dateElements = document.querySelectorAll('#current-date');
    dateElements.forEach(element => {
        element.textContent = dateString;
    });
}

// Update user interface
function updateUserInterface() {
    if (!currentUser) return;
    
    // Update user profile in sidebar
    const userName = document.querySelector('.user-info h4');
    const userRole = document.querySelector('.user-info p');
    
    if (userName) userName.textContent = currentUser.name;
    if (userRole) userRole.textContent = currentUser.role;
}

// Load attendance data
function loadAttendanceData() {
    const stored = localStorage.getItem('attendanceData');
    if (stored) {
        attendanceData = JSON.parse(stored);
    } else {
        // Generate sample data
        generateSampleData();
    }
}

// Save attendance data
function saveAttendanceData() {
    localStorage.setItem('attendanceData', JSON.stringify(attendanceData));
}

// Generate sample data
function generateSampleData() {
    const sampleData = [
        {
            id: 1,
            employeeId: 'EMP001',
            employeeName: 'Sarah Johnson',
            department: 'Development',
            date: new Date().toDateString(),
            checkIn: '08:45 AM',
            checkOut: '06:30 PM',
            status: 'present'
        },
        {
            id: 2,
            employeeId: 'EMP002',
            employeeName: 'Michael Chen',
            department: 'Marketing',
            date: new Date().toDateString(),
            checkIn: '09:15 AM',
            checkOut: '06:00 PM',
            status: 'late'
        },
        {
            id: 3,
            employeeId: 'EMP003',
            employeeName: 'Emily Davis',
            department: 'Sales',
            date: new Date().toDateString(),
            checkIn: null,
            checkOut: null,
            status: 'absent'
        }
    ];
    
    attendanceData = sampleData;
    saveAttendanceData();
}

// Update dashboard
function updateDashboard() {
    // Update statistics
    updateStatistics();
    
    // Update recent activity
    updateRecentActivity();
    
    // Update charts
    updateCharts();
}

// Update statistics
function updateStatistics() {
    const today = new Date().toDateString();
    const todayRecords = attendanceData.filter(record => record.date === today);
    
    const present = todayRecords.filter(record => record.status === 'present').length;
    const absent = todayRecords.filter(record => record.status === 'absent').length;
    const late = todayRecords.filter(record => record.status === 'late').length;
    const onLeave = todayRecords.filter(record => record.status === 'leave').length;
    
    // Update stat cards
    updateStatCard('present', present);
    updateStatCard('absent', absent);
    updateStatCard('late', late);
    updateStatCard('on-leave', onLeave);
}

// Update stat card
function updateStatCard(type, value) {
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach(card => {
        const icon = card.querySelector('.stat-icon');
        if (icon && icon.classList.contains(type)) {
            const count = card.querySelector('h3');
            if (count) count.textContent = value;
        }
    });
}

// Update recent activity
function updateRecentActivity() {
    const activityList = document.querySelector('.activity-list');
    if (!activityList) return;
    
    // Sort attendance data by most recent
    const sortedData = [...attendanceData].sort((a, b) => b.id - a.id).slice(0, 5);
    
    activityList.innerHTML = sortedData.map(record => `
        <div class="activity-item">
            <div class="activity-icon ${record.status}">
                <i class="fas fa-${getActivityIcon(record.status)}"></i>
            </div>
            <div class="activity-details">
                <h4>${record.employeeName}</h4>
                <p>${getActivityText(record)}</p>
                <span class="activity-time">Just now</span>
            </div>
        </div>
    `).join('');
}

// Get activity icon
function getActivityIcon(status) {
    const icons = {
        'present': 'sign-in-alt',
        'absent': 'user-times',
        'late': 'clock',
        'leave': 'calendar-times'
    };
    return icons[status] || 'user';
}

// Get activity text
function getActivityText(record) {
    if (record.checkIn && record.checkOut) {
        return `Checked out at ${record.checkOut}`;
    } else if (record.checkIn) {
        return `Checked in at ${record.checkIn}`;
    } else if (record.status === 'absent') {
        return 'Marked absent';
    } else if (record.status === 'leave') {
        return 'On leave';
    }
    return 'No activity';
}

// Update charts
function updateCharts() {
    // Update attendance chart
    updateAttendanceChart();
    
    // Update department chart
    updateDepartmentChart();
}

// Update attendance chart
function updateAttendanceChart() {
    const chartBars = document.querySelectorAll('.chart-bars .bar');
    if (chartBars.length === 0) return;
    
    // Sample data for the week
    const weekData = [85, 92, 88, 95, 90];
    
    chartBars.forEach((bar, index) => {
        const barFill = bar.querySelector('.bar-fill');
        const barValue = bar.querySelector('.bar-value');
        
        if (barFill && barValue) {
            const height = weekData[index];
            barFill.style.height = `${height}%`;
            barValue.textContent = `${height}%`;
        }
    });
}

// Update department chart
function updateDepartmentChart() {
    const departmentChart = document.querySelector('.department-chart');
    if (!departmentChart) return;
    
    // Sample department data
    const departmentData = [
        { name: 'Development', score: 96 },
        { name: 'Marketing', score: 92 },
        { name: 'Sales', score: 88 },
        { name: 'Human Resources', score: 94 }
    ];
    
    const chartHTML = departmentData.map(dept => `
        <div class="department-item">
            <div class="department-info">
                <span class="department-name">${dept.name}</span>
                <span class="department-score">${dept.score}%</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${dept.score}%"></div>
            </div>
        </div>
    `).join('');
    
    departmentChart.innerHTML = chartHTML;
}

// Initialize charts
function initializeCharts() {
    updateCharts();
}

// Update attendance table
function updateAttendanceTable() {
    const tableBody = document.querySelector('.attendance-table-data tbody');
    if (!tableBody) return;
    
    const tableHTML = attendanceData.map(record => `
        <tr>
            <td>
                <input type="checkbox" class="select-row">
            </td>
            <td>
                <div class="employee-info">
                    <div class="employee-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="employee-details">
                        <h4>${record.employeeName}</h4>
                        <p>${record.employeeId}</p>
                    </div>
                </div>
            </td>
            <td>
                <span class="department-badge ${record.department.toLowerCase()}">${record.department}</span>
            </td>
            <td>${record.date}</td>
            <td>${record.checkIn || '--'}</td>
            <td>${record.checkOut || '--'}</td>
            <td>${calculateDuration(record)}</td>
            <td>
                <span class="status-badge ${record.status}">${record.status}</span>
            </td>
            <td>
                <div class="table-actions">
                    <button class="action-btn edit" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn view" title="View Details">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
    
    tableBody.innerHTML = tableHTML;
}

// Calculate duration
function calculateDuration(record) {
    if (!record.checkIn || !record.checkOut) return '--';
    
    // Simple duration calculation (in a real app, this would be more sophisticated)
    const checkIn = new Date(`2000-01-01 ${record.checkIn}`);
    const checkOut = new Date(`2000-01-01 ${record.checkOut}`);
    const diff = checkOut - checkIn;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
}

// Update reports
function updateReports() {
    // Update key metrics
    updateKeyMetrics();
    
    // Update charts
    updateCharts();
    
    // Update reports table
    updateReportsTable();
}

// Update key metrics
function updateKeyMetrics() {
    const metrics = calculateKeyMetrics();
    
    const metricCards = document.querySelectorAll('.metric-card');
    metricCards.forEach(card => {
        const icon = card.querySelector('.metric-icon');
        const value = card.querySelector('h3');
        
        if (icon && value) {
            if (icon.classList.contains('percentage')) {
                value.textContent = `${metrics.attendanceRate}%`;
            } else if (icon.classList.contains('clock')) {
                value.textContent = `${metrics.avgWorkHours}h`;
            } else if (icon.classList.contains('user-times')) {
                value.textContent = `${metrics.absenteeismRate}%`;
            } else if (icon.classList.contains('running')) {
                value.textContent = `${metrics.lateArrivalRate}%`;
            }
        }
    });
}

// Calculate key metrics
function calculateKeyMetrics() {
    // Sample calculations (in a real app, this would use actual data)
    return {
        attendanceRate: 94.5,
        avgWorkHours: 8.2,
        absenteeismRate: 3.2,
        lateArrivalRate: 8.7
    };
}

// Update reports table
function updateReportsTable() {
    const tableBody = document.querySelector('.reports-table tbody');
    if (!tableBody) return;
    
    // Generate sample report data
    const reportData = generateReportData();
    
    const tableHTML = reportData.map(record => `
        <tr>
            <td>
                <div class="employee-info">
                    <div class="employee-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="employee-details">
                        <h4>${record.name}</h4>
                        <p>${record.id}</p>
                    </div>
                </div>
            </td>
            <td>
                <span class="department-badge ${record.department.toLowerCase()}">${record.department}</span>
            </td>
            <td>${record.daysPresent}</td>
            <td>${record.daysAbsent}</td>
            <td>${record.lateArrivals}</td>
            <td>${record.earlyDepartures}</td>
            <td>${record.overtimeHours}</td>
            <td>
                <span class="rate-badge ${getRateClass(record.attendanceRate)}">${record.attendanceRate}%</span>
            </td>
            <td>
                <div class="table-actions">
                    <button class="action-btn view" title="View Details">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn download" title="Download Report">
                        <i class="fas fa-download"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
    
    tableBody.innerHTML = tableHTML;
}

// Generate report data
function generateReportData() {
    return [
        {
            name: 'Sarah Johnson',
            id: 'EMP001',
            department: 'Development',
            daysPresent: 22,
            daysAbsent: 1,
            lateArrivals: 2,
            earlyDepartures: 1,
            overtimeHours: 12.5,
            attendanceRate: 95.7
        },
        {
            name: 'Michael Chen',
            id: 'EMP002',
            department: 'Marketing',
            daysPresent: 20,
            daysAbsent: 2,
            lateArrivals: 5,
            earlyDepartures: 3,
            overtimeHours: 8.0,
            attendanceRate: 87.0
        },
        {
            name: 'Emily Davis',
            id: 'EMP003',
            department: 'Sales',
            daysPresent: 21,
            daysAbsent: 1,
            lateArrivals: 1,
            earlyDepartures: 0,
            overtimeHours: 15.2,
            attendanceRate: 95.5
        }
    ];
}

// Get rate class
function getRateClass(rate) {
    if (rate >= 95) return 'excellent';
    if (rate >= 85) return 'good';
    if (rate >= 75) return 'fair';
    return 'poor';
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        min-width: 300px;
        animation: slideIn 0.3s ease;
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Setup close button
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.remove();
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Get notification icon
function getNotificationIcon(type) {
    const icons = {
        'success': 'check-circle',
        'error': 'exclamation-circle',
        'warning': 'exclamation-triangle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Get notification color
function getNotificationColor(type) {
    const colors = {
        'success': '#16a34a',
        'error': '#dc2626',
        'warning': '#d97706',
        'info': '#3b82f6'
    };
    return colors[type] || '#3b82f6';
}

// Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .notification-content {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .notification-close {
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        padding: 0.25rem;
        border-radius: 4px;
    }
    
    .notification-close:hover {
        background: rgba(255, 255, 255, 0.2);
    }
    
    .rate-badge.excellent {
        background: #dcfce7;
        color: #16a34a;
    }
    
    .rate-badge.good {
        background: #dbeafe;
        color: #2563eb;
    }
    
    .rate-badge.fair {
        background: #fef3c7;
        color: #d97706;
    }
    
    .rate-badge.poor {
        background: #fef2f2;
        color: #dc2626;
    }
    
    .department-badge.development {
        background: #e0e7ff;
        color: #4f46e5;
    }
    
    .department-badge.marketing {
        background: #dcfce7;
        color: #16a34a;
    }
    
    .department-badge.sales {
        background: #fef3c7;
        color: #d97706;
    }
    
    .department-badge.hr {
        background: #fce7f3;
        color: #ec4899;
    }
    
    .progress-fill {
        background: linear-gradient(135deg, #4f46e5, #7c3aed);
        transition: width 0.3s ease;
    }
    
    .progress-fill.overtime {
        background: linear-gradient(135deg, #16a34a, #22c55e);
    }
    
    .progress-fill.early {
        background: linear-gradient(135deg, #dc2626, #ef4444);
    }
    
    .progress-fill.perfect {
        background: linear-gradient(135deg, #3b82f6, #60a5fa);
    }
    
    .progress-fill.weekend {
        background: linear-gradient(135deg, #8b5cf6, #a78bfa);
    }
`;
document.head.appendChild(style);
