# Simple HTML Project

A clean, responsive, and modern website built with pure HTML, CSS, and JavaScript. This project demonstrates fundamental web development concepts and best practices.

## 🚀 Features

- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Modern UI**: Clean and professional design with smooth animations
- **Multiple Pages**: Home, About, Services, and Contact pages
- **Interactive Elements**: Contact form, smooth scrolling, and dynamic navigation
- **SEO Friendly**: Semantic HTML5 structure and proper meta tags
- **Cross-browser Compatible**: Works on all modern browsers

## 📁 Project Structure

```
simple-project/
├── index.html          # Main homepage
├── about.html          # About us page
├── services.html       # Services page
├── contact.html        # Contact page
├── style.css          # Main stylesheet
├── script.js          # JavaScript functionality
└── README.md          # This file
```

## 🛠️ Technologies Used

- **HTML5**: Semantic markup and modern structure
- **CSS3**: Flexbox, Grid, animations, and responsive design
- **Vanilla JavaScript**: No frameworks, pure JavaScript functionality
- **Font Awesome**: Icons (via CDN)

## 📱 Pages Overview

### Homepage (index.html)
- Hero section with call-to-action
- Features overview
- Services preview
- Contact form

### About Page (about.html)
- Company story and mission
- Team members with avatars
- Statistics and achievements
- Company values

### Services Page (services.html)
- Detailed service descriptions
- Process workflow
- Service cards with icons
- Pricing information

### Contact Page (contact.html)
- Contact information
- Interactive contact form
- FAQ section
- Location map placeholder

## 🎨 Design Features

- **Color Scheme**: Professional blue and gray palette
- **Typography**: Clean, readable fonts
- **Animations**: Smooth transitions and hover effects
- **Layout**: Grid and flexbox layouts
- **Responsive**: Mobile-first design approach

## ⚡ JavaScript Features

- **Smooth Scrolling**: Navigation links scroll smoothly to sections
- **Form Validation**: Client-side validation for contact forms
- **Mobile Menu**: Responsive navigation toggle
- **Scroll to Top**: Button that appears when scrolling down
- **Intersection Observer**: Animations when elements come into view
- **Dynamic Footer**: Automatically updates copyright year

## 🚀 Getting Started

1. **Download the files** to your local machine
2. **Open `index.html`** in your web browser
3. **Navigate** through the different pages
4. **Test the contact form** and other interactive features

## 📱 Responsive Breakpoints

- **Desktop**: 1200px and above
- **Tablet**: 768px - 1199px
- **Mobile**: 320px - 767px

## 🌐 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Opera (latest)

## 🔧 Customization

### Changing Colors
Edit the CSS variables in `style.css`:
```css
:root {
    --primary-color: #3498db;
    --secondary-color: #2c3e50;
    --accent-color: #e74c3c;
}
```

### Adding New Pages
1. Create a new HTML file
2. Copy the structure from existing pages
3. Update the navigation menu
4. Add your content

### Modifying Layout
Edit the CSS grid and flexbox properties in `style.css` to change the layout structure.

## 📧 Contact Form

The contact form includes:
- Name validation
- Email validation
- Phone number validation
- Subject selection
- Newsletter subscription option
- Success/error messaging

## 🎯 Best Practices Demonstrated

- **Semantic HTML5**: Proper use of header, nav, main, section, footer
- **Accessibility**: ARIA labels and semantic markup
- **Performance**: Optimized CSS and JavaScript
- **SEO**: Meta tags and proper heading structure
- **Mobile-First**: Responsive design approach
- **Progressive Enhancement**: Works without JavaScript

## 🚀 Deployment

This project can be deployed to any static hosting service:
- Netlify
- Vercel
- GitHub Pages
- Firebase Hosting
- Any traditional web server

## 📝 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Feel free to fork this project and submit pull requests with improvements!

## 📞 Support

If you have any questions or need help with customization, feel free to reach out through the contact form or create an issue in the repository.
